import { QueryObject } from './types';
export default function normalizeOrderBy(queryObject: QueryObject): QueryObject;
//# sourceMappingURL=normalizeOrderBy.d.ts.map