import { SimpleAdhocFilter } from './types/Filter';
import { QueryObjectFilterClause } from './types/Query';
export default function convertFilter(filter: SimpleAdhocFilter): QueryObjectFilterClause;
//# sourceMappingURL=convertFilter.d.ts.map