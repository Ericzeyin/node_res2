import { QueryFormMetric } from './types';
export default function getMetricLabel(metric: QueryFormMetric): string;
//# sourceMappingURL=getMetricLabel.d.ts.map