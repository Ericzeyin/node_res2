import { QueryFormData } from './types/QueryFormData';
/** Logic formerly in viz.py's process_query_filters */
export default function processFilters(formData: Partial<QueryFormData>): Partial<QueryFormData>;
//# sourceMappingURL=processFilters.d.ts.map