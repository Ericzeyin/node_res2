export default function validateInteger(v: unknown): string | false;
//# sourceMappingURL=validateNumber.d.ts.map