/**
 * formerly called integer()
 * @param v
 */
export default function legacyValidateInteger(v: unknown): string | false;
//# sourceMappingURL=legacyValidateInteger.d.ts.map