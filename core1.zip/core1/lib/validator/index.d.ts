export { default as legacyValidateInteger } from './legacyValidateInteger';
export { default as legacyValidateNumber } from './legacyValidateNumber';
export { default as validateInteger } from './validateInteger';
export { default as validateNumber } from './validateNumber';
export { default as validateNonEmpty } from './validateNonEmpty';
//# sourceMappingURL=index.d.ts.map