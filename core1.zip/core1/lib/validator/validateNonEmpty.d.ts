export default function validateNonEmpty(v: unknown): string | false;
//# sourceMappingURL=validateNonEmpty.d.ts.map