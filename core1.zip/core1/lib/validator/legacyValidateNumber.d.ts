/**
 * formerly called numeric()
 * @param v
 */
export default function numeric(v: unknown): string | false;
//# sourceMappingURL=legacyValidateNumber.d.ts.map