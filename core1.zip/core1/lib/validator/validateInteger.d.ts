export default function validateInteger(v: unknown): string | false;
//# sourceMappingURL=validateInteger.d.ts.map