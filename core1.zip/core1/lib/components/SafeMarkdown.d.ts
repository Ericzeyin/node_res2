/// <reference types="react" />
interface SafeMarkdownProps {
    source: string;
}
declare function SafeMarkdown({ source }: SafeMarkdownProps): JSX.Element;
export default SafeMarkdown;
//# sourceMappingURL=SafeMarkdown.d.ts.map