import { SupersetClientInterface } from './types';
declare const SupersetClient: SupersetClientInterface;
export default SupersetClient;
//# sourceMappingURL=SupersetClient.d.ts.map