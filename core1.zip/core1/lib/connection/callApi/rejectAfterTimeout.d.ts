export default function rejectAfterTimeout<T>(timeout: number): Promise<T>;
//# sourceMappingURL=rejectAfterTimeout.d.ts.map