export { default } from './callApiAndParseWithTimeout';
//# sourceMappingURL=index.d.ts.map