export declare type ChartControlPanel = {
    [key: string]: any;
};
//# sourceMappingURL=ChartControlPanel.d.ts.map