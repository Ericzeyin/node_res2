/// <reference types="react" />
import { FallbackPropsWithDimension } from './SuperChart';
export declare type Props = FallbackPropsWithDimension;
export default function FallbackComponent({ componentStack, error, height, width, }: Props): JSX.Element;
//# sourceMappingURL=FallbackComponent.d.ts.map