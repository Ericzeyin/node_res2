declare type Props = {
    className?: string;
    height: number | string;
    id?: string;
    width: number | string;
};
declare const NoResultsComponent: ({ className, height, id, width }: Props) => JSX.Element;
export default NoResultsComponent;
//# sourceMappingURL=NoResultsComponent.d.ts.map