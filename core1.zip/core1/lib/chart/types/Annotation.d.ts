export declare type AnnotationLayerMetadata = {
    name: string;
    sourceType?: string;
};
//# sourceMappingURL=Annotation.d.ts.map