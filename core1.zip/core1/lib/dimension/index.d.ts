export { default as getTextDimension } from './getTextDimension';
export { default as getMultipleTextDimensions } from './getMultipleTextDimensions';
export { default as computeMaxFontSize } from './computeMaxFontSize';
export { default as mergeMargin } from './mergeMargin';
export { default as parseLength } from './parseLength';
export * from './types';
export { default as __hack_reexport_dimension } from './types';
//# sourceMappingURL=index.d.ts.map