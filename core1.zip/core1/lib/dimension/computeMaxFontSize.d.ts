import { GetTextDimensionInput } from './getTextDimension';
export default function computeMaxFontSize(input: GetTextDimensionInput & {
    maxWidth?: number;
    maxHeight?: number;
    idealFontSize?: number;
}): number;
//# sourceMappingURL=computeMaxFontSize.d.ts.map