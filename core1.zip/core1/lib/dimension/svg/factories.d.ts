import LazyFactory from './LazyFactory';
export declare const hiddenSvgFactory: LazyFactory<SVGSVGElement>;
export declare const textFactory: LazyFactory<SVGTextElement>;
//# sourceMappingURL=factories.d.ts.map