export default function createHiddenSvgNode(): SVGSVGElement;
//# sourceMappingURL=createHiddenSvgNode.d.ts.map