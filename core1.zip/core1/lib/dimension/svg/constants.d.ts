export declare const SVG_NS = "http://www.w3.org/2000/svg";
//# sourceMappingURL=constants.d.ts.map