import { Dimension } from '../types';
export default function getBBoxCeil(node: SVGGraphicsElement, defaultDimension?: Dimension): {
    height: number;
    width: number;
};
//# sourceMappingURL=getBBoxCeil.d.ts.map