import { TextStyle } from '../types';
export default function updateTextNode(node: SVGTextElement, { className, style, text, }?: {
    className?: string;
    style?: TextStyle;
    text?: string;
}): SVGTextElement;
//# sourceMappingURL=updateTextNode.d.ts.map