export default function createTextNode(): SVGTextElement;
//# sourceMappingURL=createTextNode.d.ts.map