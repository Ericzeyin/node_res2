export default function parseLength(input: string | number): {
    isDynamic: true;
    multiplier: number;
} | {
    isDynamic: false;
    value: number;
};
//# sourceMappingURL=parseLength.d.ts.map