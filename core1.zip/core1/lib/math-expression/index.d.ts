export declare function evalExpression(expression: string, value: number): number;
export declare function isValidExpression(expression: string): boolean;
//# sourceMappingURL=index.d.ts.map