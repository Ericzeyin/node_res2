declare const smartDateFormatter: import("../TimeFormatter").default;
export default smartDateFormatter;
//# sourceMappingURL=smartDateVerbose.d.ts.map