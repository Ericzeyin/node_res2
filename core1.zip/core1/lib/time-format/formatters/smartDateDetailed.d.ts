declare const smartDateDetailedFormatter: import("../TimeFormatter").default;
export default smartDateDetailedFormatter;
//# sourceMappingURL=smartDateDetailed.d.ts.map