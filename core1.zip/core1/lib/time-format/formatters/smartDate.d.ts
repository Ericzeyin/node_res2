declare const smartDateFormatter: import("../TimeFormatter").default;
export default smartDateFormatter;
//# sourceMappingURL=smartDate.d.ts.map