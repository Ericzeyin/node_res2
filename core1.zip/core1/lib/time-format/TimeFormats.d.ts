export declare const LOCAL_PREFIX = "local!";
declare const TimeFormats: {
    DATABASE_DATE: string;
    DATABASE_DATETIME: string;
    DATABASE_DATETIME_REVERSE: string;
    INTERNATIONAL_DATE: string;
    TIME: string;
    US_DATE: string;
};
export default TimeFormats;
//# sourceMappingURL=TimeFormats.d.ts.map