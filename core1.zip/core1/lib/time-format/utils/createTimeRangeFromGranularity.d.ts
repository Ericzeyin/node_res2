import { TimeGranularity } from '../types';
export default function createTimeRangeFromGranularity(time: Date, granularity: TimeGranularity, useLocalTime?: boolean): Date[];
//# sourceMappingURL=createTimeRangeFromGranularity.d.ts.map