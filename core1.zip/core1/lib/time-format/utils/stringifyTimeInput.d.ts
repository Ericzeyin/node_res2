export default function stringifyTimeInput(value: Date | number | undefined | null, fn: (time: Date) => string): string;
//# sourceMappingURL=stringifyTimeInput.d.ts.map