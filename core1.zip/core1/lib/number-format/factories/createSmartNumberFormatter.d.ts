import NumberFormatter from '../NumberFormatter';
export default function createSmartNumberFormatter(config?: {
    description?: string;
    signed?: boolean;
    id?: string;
    label?: string;
}): NumberFormatter;
//# sourceMappingURL=createSmartNumberFormatter.d.ts.map