import NumberFormatter from '../NumberFormatter';
export default function createSiAtMostNDigitFormatter(config?: {
    description?: string;
    n?: number;
    id?: string;
    label?: string;
}): NumberFormatter;
//# sourceMappingURL=createSiAtMostNDigitFormatter.d.ts.map