export declare type NumberFormatFunction = (value: number) => string;
//# sourceMappingURL=types.d.ts.map