export declare function getContrastingColor(color: string, thresholds?: number): "#000" | "#FFF";
//# sourceMappingURL=utils.d.ts.map