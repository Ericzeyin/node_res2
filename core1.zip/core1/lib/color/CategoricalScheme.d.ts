import ColorScheme from './ColorScheme';
export default class CategoricalScheme extends ColorScheme {
}
//# sourceMappingURL=CategoricalScheme.d.ts.map