import SequentialScheme from '../../SequentialScheme';
declare const schemes: SequentialScheme[];
export default schemes;
//# sourceMappingURL=d3.d.ts.map