export * from './categorical';
export * from './sequential';
//# sourceMappingURL=index.d.ts.map