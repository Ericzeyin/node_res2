import CategoricalScheme from '../../CategoricalScheme';
declare const schemes: CategoricalScheme[];
export default schemes;
//# sourceMappingURL=lyft.d.ts.map