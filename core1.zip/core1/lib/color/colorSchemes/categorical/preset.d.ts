import CategoricalScheme from '../../CategoricalScheme';
declare const schemes: CategoricalScheme[];
export default schemes;
//# sourceMappingURL=preset.d.ts.map