import CategoricalScheme from '../../CategoricalScheme';
declare const schemes: CategoricalScheme[];
export default schemes;
//# sourceMappingURL=airbnb.d.ts.map