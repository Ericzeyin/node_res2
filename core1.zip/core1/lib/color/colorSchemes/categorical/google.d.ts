import CategoricalScheme from '../../CategoricalScheme';
declare const schemes: CategoricalScheme[];
export default schemes;
//# sourceMappingURL=google.d.ts.map