import CategoricalScheme from '../../CategoricalScheme';
declare const schemes: CategoricalScheme[];
export default schemes;
//# sourceMappingURL=d3.d.ts.map