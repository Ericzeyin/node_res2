/**
 * Ensure value is a string
 * @param {any} value
 */
export default function stringifyAndTrim(value?: number | string): string;
//# sourceMappingURL=stringifyAndTrim.d.ts.map