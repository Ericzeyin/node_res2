export interface ColorsLookup {
    [key: string]: string;
}
//# sourceMappingURL=types.d.ts.map