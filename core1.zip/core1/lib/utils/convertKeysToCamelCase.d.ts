export default function convertKeysToCamelCase<T>(object: T): T;
//# sourceMappingURL=convertKeysToCamelCase.d.ts.map