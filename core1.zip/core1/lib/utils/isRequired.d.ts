export default function isRequired(field: string): never;
//# sourceMappingURL=isRequired.d.ts.map