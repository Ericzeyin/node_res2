export default function isDefined(x: unknown): boolean;
//# sourceMappingURL=isDefined.d.ts.map