export * from './TranslatorSingleton';
export * from './types';
declare const _default: {};
export default _default;
export { default as __hack_reexport_trasnslation } from './types';
//# sourceMappingURL=index.d.ts.map