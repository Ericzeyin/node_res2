
// `victory-vendor/d3-array` (TypeScript)
//
// Export the type definitions for this package:
export * from "d3-array";
