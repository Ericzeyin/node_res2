
// `victory-vendor/d3-scale` (TypeScript)
//
// Export the type definitions for this package:
export * from "d3-scale";
