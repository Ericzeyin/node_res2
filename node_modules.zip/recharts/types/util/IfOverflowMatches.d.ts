export declare const ifOverflowMatches: (props: any, value: string) => boolean;
