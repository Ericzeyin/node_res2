export declare function getEveryNthWithCondition<Type>(array: Type[], n: number, isValid?: (candidate: Type) => boolean): Type[] | undefined;
