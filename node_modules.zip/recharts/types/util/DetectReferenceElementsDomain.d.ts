import { ReactNode } from 'react';
export declare const detectReferenceElementsDomain: (children: ReactNode[], domain: number[], axisId: string, axisType: string, specifiedTicks?: any[]) => number[];
