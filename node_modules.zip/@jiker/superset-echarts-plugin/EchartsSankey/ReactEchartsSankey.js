import reactify from '@superset-ui/core/esm/chart/components/reactify';
import Component from './EchartsSankey';

export default reactify(Component);
