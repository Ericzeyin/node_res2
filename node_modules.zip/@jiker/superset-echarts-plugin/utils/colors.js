export const formatColor = obj =>
  `rgba(${obj.r}, ${obj.g}, ${obj.b}, ${obj.a})`;
