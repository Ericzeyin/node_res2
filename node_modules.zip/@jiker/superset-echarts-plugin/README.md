# @jiker/superset-echarts-plugin

![](https://img.shields.io/badge/-jiker-brightgreen)
![](https://img.shields.io/npm/dw/@jiker/superset-echarts-plugin)
![](https://img.shields.io/npm/v/@jiker/superset-echarts-plugin)
![](https://img.shields.io/npm/l/@jiker/superset-echarts-plugin)
![](https://img.shields.io/npm/collaborators/@jiker/superset-echarts-plugin)

> Jiker Superset Chart - Echarts.

## Usage

Configure `key`, which can be any `string`, and register the plugin. This `key` will be used to
lookup this chart throughout the app.

```js
import {
  JkEchartsBarChartPlugin,
  JkEchartsDiyChartPlugin,
  JkEchartsGanttChartPlugin,
  JkEchartsHydrographChartPlugin,
  JkEchartsLineChartPlugin,
  JkEchartsLineBarChartPlugin,
  JkEchartsPieChartPlugin,
  JkEchartsSankeyChartPlugin,
  JkEchartsScatterChartPlugin,
  JkNumberChartPlugin,
} from '@jiker/superset-echarts-plugin';

new JkEchartsBarChartPlugin().configure({ key: 'echarts_bar' }).register();
new JkEchartsDiyChartPlugin().configure({ key: 'echarts_diy' }).register();
new JkEchartsGanttChartPlugin().configure({ key: 'echarts_gantt' }).register();
new JkEchartsHydrographChartPlugin().configure({ key: 'echarts_hydrograph' }).register();
new JkEchartsLineChartPlugin().configure({ key: 'echarts_line' }).register();
new JkEchartsLineBarChartPlugin().configure({ key: 'echarts_line_bar' }).register();
new JkEchartsPieChartPlugin().configure({ key: 'echarts_pie' }).register();
new JkEchartsSankeyChartPlugin().configure({ key: 'echarts_sankey' }).register();
new JkEchartsScatterChartPlugin().configure({ key: 'echarts_scatter' }).register();
new JkNumberChartPlugin().configure({ key: 'jk_number' }).register();
```

## License
[MIT](http://git.jiker-inc.com/jiker/npm/superset-echarts-plugin/blob/master/LICENSE)

Copyright (c) 2021-present zhuhuajian
