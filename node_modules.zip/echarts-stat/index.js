module.exports = require('./dist/ecStat.js');
