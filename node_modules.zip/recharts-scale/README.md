# recharts-scale

[![Build Status](https://github.com/recharts/recharts-scale/workflows/ci/badge.svg)](https://github.com/recharts/recharts-scale/actions)

Scale of Cartesian Coordinates
