export { getTickValues, getNiceTickValues, getTickValuesFixedDomain } from './getNiceTickValues';
