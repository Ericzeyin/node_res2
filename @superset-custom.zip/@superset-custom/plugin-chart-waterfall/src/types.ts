export enum LegendPosition {
  TOP = 'top',
  BOTTOM = 'bottom',
}
